# 🛰️ Standing & Terbang Toolkit — *mod by xstorevpn*

Kumpulan tool **analisis jaringan, host/SNI, dan APK** dalam satu paket — dibuat untuk berjalan di **Termux (non-root)**. Menggabungkan beberapa tool populer + utilitas tambahan, dilengkapi **installer otomatis**, **menu interaktif**, dan mode **Smart Scan** (analisis lengkap sekali jalan).

> 🔧 **Mod by xstorevpn:** tahap *Response-Checker* (cek host response) dihilangkan karena sering error (`user-agents.txt not found`) setelah scan selesai. Smart Scan sekarang berhenti rapi setelah tahap CDN + TLS + port.

> ⚠️ **Disclaimer:** Toolkit ini ditujukan untuk **edukasi & pengujian yang sah** (jaringan/aplikasi milik sendiri atau yang Anda punya izin untuk diuji). Gunakan secara bertanggung jawab dan sesuai hukum yang berlaku.

---

## 📦 Tool yang tergabung

| Tool | Fungsi | Sumber |
|------|--------|--------|
| **BugScanX** | All-in-one pencari SNI bug host (scanner, subdomain, reverse IP, port, SSL/DNS) | [FreeNetLabs/BugScanX](https://github.com/FreeNetLabs/BugScanX) |
| **ApkPatcher** | Patch APK (SSL bypass, merge split APK, dll) | [TechnoIndian/ApkPatcher](https://github.com/TechnoIndian/ApkPatcher) |
| **domainfinder** *(lokal)* | Ekstrak domain & host/SNI dari file APK/APKS/XAPK/APKM | toolkit ini |
| **cdncheck** *(lokal)* | Deteksi CDN (Cloudflare / CloudFront) **+ versi TLS + cek port 80/443**, scan paralel | toolkit ini |
| **snicheck** *(lokal)* | Inspeksi TLS/SNI handshake + detail sertifikat (CN, SAN, issuer, expiry) — opsional | toolkit ini |
| **smartscan** *(lokal)* | Orchestrator: APK → domain → CDN+TLS, sekali jalan + laporan terpadu | toolkit ini |

---

## 🚀 Instalasi (Termux)

```bash
# 0. Pasang git dulu (sekali saja, kalau belum ada)
pkg update -y && pkg install git -y

# 1. Clone repo ini
git clone https://github.com/sukesiqqqq-design/standing-dan-melayang-by-xstorevpn

# 2. Masuk ke folder script (ada di dalam subfolder)
cd standing-dan-melayang-by-xstorevpn/Standing-dan-terbang

# 3. Jalankan installer (otomatis pasang semua)
bash install.sh
```

Installer memasang: `python`, `git`, `curl`, `wget`, `unzip`, `binutils`, `dnsutils`, `openssl-tool`, `openjdk-17`, `apktool`, **BugScanX**, **ApkPatcher**, serta meng-_install_ perintah `domainfinder`, `cdncheck`, `snicheck`, `smartscan`, dan menu `stt`.

---

## 🎮 Cara pakai

### Lewat menu (paling mudah)
```bash
stt
```

Daftar menu:
```
 1) BugScanX         6) Smart Scan (analisis lengkap 1x)
 2) ApkPatcher       7) Update semua tool
 3) Domain Finder    8) Cek status / versi
 4) CDN+TLS+Port      9) Uninstall toolkit
 5) SNI/TLS Detail  10) Bantuan / Penjelasan
```

### Lewat perintah langsung

| Perintah | Keterangan |
|----------|-----------|
| `bugscanx` | Buka BugScanX (alias: `bx`) |
| `ApkPatcher -h` | Bantuan ApkPatcher |
| `ApkPatcher -i app.apk` | Patch APK (default SSL bypass) |
| `ApkPatcher -m app.apks` | Merge split APK jadi satu `.apk` |
| `domainfinder app.apks` | Ambil daftar domain/host dari APK |
| `cdncheck domains.txt` | Deteksi CDN + versi TLS + port 80/443 (paralel) |
| `cdncheck domains.txt 20` | Sama, dengan 20 proses paralel |
| `snicheck host.com` | Detail sertifikat TLS/SNI 1 host (opsional) |
| `snicheck domains.txt 443` | Detail sertifikat banyak host (port opsional) |
| `smartscan app.apks` | **Analisis lengkap sekali jalan** |

---

## ⭐ Smart Scan — analisis lengkap sekali jalan

Cukup satu perintah, semua tahap otomatis berurutan:

```bash
smartscan /sdcard/Download/myXL_9.2.0.apks
```

Tahapannya:
1. **domainfinder** → ekstrak semua domain/host (auto-merge kalau `.apks`)
2. **cdncheck** → kelompokkan Cloudflare / CloudFront / origin **+ versi TLS + port 80/443** tiap domain (paralel)

Hasil dikumpulkan rapi di:
```
~/STT-results/<nama-app>/
├── <nama>_domains.txt
├── <nama>_domains_cloudflare.txt
├── <nama>_domains_cloudfront.txt
├── <nama>_domains_origin.txt
├── <nama>_domains_cdn_tls.txt   # tabel: domain | CDN | TLS | 80 | 443
└── report.txt          # ← ringkasan semua tahap
```
Folder ini otomatis disalin juga ke `/sdcard/Download/<nama-app>/`.

---

## 🔄 Contoh alur manual (step-by-step)

```bash
# 1. Ambil domain/host dari aplikasi
domainfinder /sdcard/Download/myXL_9.2.0.apks

# 2. Deteksi CDN + versi TLS + port 80/443 (paralel)
cdncheck ~/domainfinder/myXL_9.2.0_domains.txt 20

# 3. (Opsional) detail sertifikat TLS/SNI pada domain origin
snicheck ~/domainfinder/myXL_9.2.0_domains_origin.txt

# 4. Scan bug host lebih dalam
bugscanx
```

---

## 📁 Struktur repo

```
Standing-dan-terbang/
├── install.sh            # installer otomatis
├── update.sh             # update semua tool
├── uninstall.sh          # hapus toolkit (folder hasil tetap aman)
├── menu.sh               # menu launcher (perintah: stt)
├── tools/
│   ├── domainfinder.sh   # ekstrak domain/host dari APK
│   ├── cdncheck.sh       # deteksi Cloudflare / CloudFront
│   ├── snicheck.sh       # inspeksi TLS/SNI & sertifikat
│   └── smartscan.sh      # orchestrator analisis lengkap
├── wordlists/
│   └── subdomains.txt    # ~200 subdomain umum untuk enumerasi
└── README.md
```

---

## 🔧 Update & Uninstall

```bash
# Update semua tool sekaligus
bash update.sh          # atau menu -> 7

# Uninstall (symlink command + opsional paket pip)
bash uninstall.sh       # atau menu -> 9
```
> Catatan: uninstall **tidak menghapus** folder hasil `~/STT-results` & `~/domainfinder`.

---

## 🙏 Kredit

Toolkit ini hanya **menggabungkan & mempermudah** penggunaan tool berikut. Semua hak & kredit milik pembuat aslinya:

- BugScanX — [FreeNetLabs](https://github.com/FreeNetLabs/BugScanX)
- ApkPatcher — [TechnoIndian](https://github.com/TechnoIndian/ApkPatcher)
- apktool (Termux) — [rendiix](https://github.com/rendiix/termux-apktool)

Mod & penyesuaian menu: **xstorevpn**.

---

## 🛠️ Troubleshooting

**`[Process completed (signal 9)]` saat scan banyak domain**
Itu artinya Android membunuh proses (biasanya karena scan lama / aplikasi pindah ke background / layar mati). Solusi:
- Toolkit kini otomatis memasang `termux-wake-lock` selama scan. Pastikan **layar HP tetap menyala** dan **jangan pindah aplikasi** saat scan besar berjalan.
- **Resume otomatis:** kalau tetap terbunuh, **cukup jalankan lagi perintah yang sama** — `cdncheck` akan melanjutkan dari domain yang belum discan (tidak mengulang dari awal). Untuk mengulang dari nol: `cdncheck domains.txt 8 fresh`.
- Kurangi jumlah paralel bila HP lemah, mis. `cdncheck domains.txt 4`.
- Hasil ditulis **bertahap**, jadi file `*_cloudflare.txt` / `*_origin.txt` / `*_cdn_tls.txt` selalu berisi sebagian hasil walau terputus.

**Kolom TLS kosong (`TLS=-`) padahal 443 open**
Wajar untuk sebagian host (menolak HEAD / handshake lambat). Gunakan `snicheck <host>` untuk inspeksi detail.

**Banyak "domain" aneh (`conv3d.cc`, `AJAX.NET`)**
Itu artefak dari kode di dalam APK. Filter `domainfinder` sudah dibuat ketat, tapi analisis statis tidak 100% bersih — domain yang tidak resolve akan tampak `closed`/`origin` saat `cdncheck` dan mudah diabaikan.
